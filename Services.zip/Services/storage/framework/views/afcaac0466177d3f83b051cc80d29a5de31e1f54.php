<html>
    <head>
        <title>Arithmetic Services</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
    </head>
    <body>
        <form method="post" >
            <?php echo csrf_field(); ?>
            <br><br><br>
            <div class="container">
            <h2>Calculator :- </h2>
            <div class="row">
            <div class="mb-3">
              <label for="exampleInputEmail1" class="form-label">Input Valude Of A</label>
              <input type="number" class="form-control" name="value_a" id="exampleInputEmail1" aria-describedby="emailHelp">
              <span style="color: red"><?php if ($errors->has('value_a')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('value_a'); ?><?php echo e($message); ?><?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?></span>  
            </div>
            <div class="mb-3">
              <label for="exampleInputPassword1" class="form-label">Input Valude Of B</label>
              <input type="number" class="form-control" name="value_b" id="exampleInputPassword1">
              <span style="color: red"><?php if ($errors->has('value_b')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('value_b'); ?><?php echo e($message); ?><?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?></span>  
            </div>
            <div class="mb-3">
            <select class="form-select" name="operation" >
                <option selected disabled value="">Open this select operation</option>
                <option value="1">Addition</option>
                <option value="2">Substraction</option>
                <option value="3">Multiplication</option>
                <option value="4">Division</option>
              </select>
              <span style="color: red"><?php if ($errors->has('operation')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('operation'); ?><?php echo e($message); ?><?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?></span>  
            <div>
            <br>
            <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </div>
        </form>

        <?php if(Session::has('success')): ?>
        <div class="alert alert-success">

        <strong role="alert" class=""><?php echo Session::get('success'); ?></strong>

        </div>

        <?php endif; ?>

        <?php if(Session::has('danger')): ?>
        <div class="alert alert-danger">

        <strong role="alert" class=""><?php echo Session::get('danger'); ?></strong>

        </div>

        <?php endif; ?>

    </body>
</html><?php /**PATH /home/nikunj/app/Services/resources/views/arithmetic.blade.php ENDPATH**/ ?>