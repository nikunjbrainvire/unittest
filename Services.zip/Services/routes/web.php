<?php

use App\Http\Controllers\ArithmeticController;
use Illuminate\Support\Facades\Mail;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::prefix('calculator')->group(function () {

    Route::get('/index', function () {
        return view('arithmetic');
    });
    Route::post('/index',[ArithmeticController::class,'index']);

});

Route::get('/mail', function() {

    dispatch(function() {
    Mail::send([], [], function($message) {
        $message->to('abc@gmail.com', 'Tutorials Point')->subject
           ('Laravel HTML Testing Mail')
           ->setBody('hi, subject');
        $message->from('xyz@gmail.com','Virat Gandhi');
     });
    })->delay(now());

});

Route::get('/event',[ArithmeticController::class,'test']);