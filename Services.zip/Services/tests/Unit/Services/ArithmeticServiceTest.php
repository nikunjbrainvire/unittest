<?php

namespace Tests\Unit\Services;

use Tests\TestCase;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Foundation\Testing\RefreshDatabase;
use App\Services\ArithmeticService;
use App\Models\Arithmetic;
use \Mockery;
use Mockery\MockInterface;
use App\Jobs\SendMailJob;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Facades\Bus;
use App\Events\ArithmeticCreated;


class ArithmeticServiceTest extends TestCase
{
    public function setUp(): void
    {   
        parent::setUp();

        $this->value= [
            "value_a"=>1,
            "value_b"=>1,
            "operation"=>2
        ];

        $this->undefineOperationValue= [
            "value_a"=>1,
            "value_b"=>1,
            "operation"=>10
        ];

        $this->divisionByZeroValue= [
            "value_a"=>0,
            "value_b"=>0,
            "operation"=>4
        ];
        $this->opraterNullValue= [
            "value_a"=>0,
            "value_b"=>"23des",
            "operation"=>1
        ];

        Bus::fake();
        
        $this->eventData= [
            "value_a"=>1,
            "value_b"=>2,
            "operation"=>1
        ];

        $this->jobData = "Test123";
        
        // $this->mockArithmeticResponse = Mockery::mock(Arithmetic::class);
        // $this->app->instance(Arithmetic::class,$this->mockArithmeticResponse);
    
        $this->ArithmeticService = $this->app->make(ArithmeticService::class);


    }

    public function testArithmeticServiceReturnsTrue(): void
    {
        
        $this->ArithmeticService = $this->ArithmeticService->operation($this->value);
        Event::fake();
        ArithmeticCreated::dispatch($this->eventData);
        Event::assertDispatched(ArithmeticCreated::class);
        SendMailJob::dispatch($this->jobData);
        Bus::assertDispatched(SendMailJob::class);
        $this->assertEquals("success", $this->ArithmeticService[0]);   
    }

    public function testArithmeticServiceDatabseNotInsert(): void
    {

        $this->expectException(\Exception::class);
        $this->ArithmeticService->operation($this->opraterNullValue);

        Event::fake();
        Event::assertNotDispatched(ArithmeticCreated::class);
        Bus::assertNotDispatched(SendMailJob::class);



    }

    public function testArithmeticServiceOperationNotFound(): void
    {
        $this->expectExceptionMessage('Some thing is Wrong Please Try Again');

        $this->ArithmeticService->operation($this->undefineOperationValue);
        
        Event::fake();
        Event::assertNotDispatched(ArithmeticCreated::class);
        Bus::assertNotDispatched(SendMailJob::class);

    }

    public function testArithmeticServiceOperationDivisionByZero()
    {
        $this->expectExceptionMessage('Division by zero');

        $this->ArithmeticService->operation($this->divisionByZeroValue);
        Event::fake();
        Event::assertNotDispatched(ArithmeticCreated::class);
        Bus::assertNotDispatched(SendMailJob::class);

    }



}
