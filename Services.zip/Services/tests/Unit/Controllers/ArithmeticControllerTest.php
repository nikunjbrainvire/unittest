<?php

namespace Tests\Unit\Controllers;

use Tests\TestCase;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Foundation\Testing\RefreshDatabase;
use App\Http\Controllers\ArithmeticController;
use Session;

class ArithmeticControllerTest extends TestCase
{
    public function setUp(): void
    {   
        parent::setUp();

        Session::start();
    }

    public function testArithmeticController():void
    {
        $response = $this->post('/calculator/index',[
            "value_a"=>1,
            "value_b"=>1,
            "operation"=>1,
            '_token' => csrf_token()
        ]);

        $response->assertStatus(302);
        $response->assertRedirect('/calculator/index');

    }

    public function testArithmeticControllerXxsAttack(): void
    {
        $response = $this->post('/calculator/index',[
            "value_a"=>1,
            "value_b"=>1,
            "operation"=>1
        ]);

        $response->assertStatus(419);
    }

    public function testtestArithmeticControllerNullValue():void
    {

        $response = $this->post('/calculator/index',[
            "value_a"=>1,
            "value_b"=>null,
            "operation"=>1,
            '_token' => csrf_token()
        ]);

        $response->assertStatus(302);
        // $response->assertSessionHasErrors(['value_b']);
        // $response->assertNull(['value_b']);


    }
}
