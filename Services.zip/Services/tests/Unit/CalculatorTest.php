<?php

namespace Tests\Unit;

use Tests\TestCase;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Foundation\Testing\RefreshDatabase;
use \Mockery;
use App\Http\Controllers\ArithmeticController;
use App\Services\Services;
use Mockery\MockInterface;
use Illuminate\Http\Request;
use App\Models\ArithmeticService;

class CalculatorTest extends TestCase
{
    /**
     * A basic unit test example.
     *
     * @return void
     */
  public function tearDown(): void
    {
        // \Mockery::close();
    }

    public function testExample()
    {
        // $idCustomer= [
        //     "value-a"=>1,
        //     "value-b"=>1,
        //     "operation"=>2
        // ];
        
        // $mockServices = Mockery::mock('Arithmeticresult');
        // $mockServices->shouldReceive('store')
        // ->once()
        // ->andReturn(true);
        
        // $mock = Mockery::mock('Services');
        // $mock->shouldReceive('operation')
        //      ->once()
        //      ->with($idCustomer)
        //      ->andReturn(["success","Substraction = 0"]);
        
        // $ArithmeticService = new ArithmeticService($mock);
        // $ArithmeticService->index($idCustomer);
        
             $response = $this->post('/calculator/index',[
                "value_a"=>1,
                "value_b"=>1,
                "operation"=>1
            ]);


        $response->assertRedirect('http://localhost/calculator/index');

    }
}
