<?php

namespace Tests\Integration\Models;

use Tests\TestCase;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Foundation\Testing\RefreshDatabase;
use App\Models\Arithmetic;
use Illuminate\Foundation\Testing\DatabaseTransactions;

class ArithmeticTest extends TestCase
{
    // use DatabaseTransactions;

    public function setUp(): void
    {   
        parent::setUp();
        $this->arithmetic = $this->app->make(Arithmetic::class);
    }
    public function testArithmeticSuccessful(): void
    {
        $data['value_a'] = 1;
        $data['value_b'] = 1;
        $task =( (int)$data['value_a'] + (int)$data['value_b'] );
        $opration = "Addition";
        $arithmetic = $this->arithmetic->store($data,$opration,$task);
        $this->assertTrue($arithmetic->exists());
    
    }
    public function testArithmeticInsertDataCheck(): void
    {
    
        $data['value_a'] = 1;
        $data['value_b'] = 1;
        $task =( (int)$data['value_a'] / (int)$data['value_b'] );
        $opration = "Check";
        $arithmetic = $this->arithmetic->store($data,$opration,$task);
        $this->assertDatabaseHas('arithmetics', [
            "opration" => $opration
        ]);	


    }

}
