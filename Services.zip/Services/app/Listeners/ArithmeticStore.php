<?php

namespace App\Listeners;

use App\Events\ArithmeticCreated;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Models\Arithmetic;

class ArithmeticStore
{
    /**
     * Create the event listener.
     * @param Arithmetic $Arithmetic
     * @return void
     */
    public $Arithmetic;
    public function __construct(Arithmetic $Arithmetic)
    {
        $this->Arithmetic = $Arithmetic;
    }

    /**
     * Handle the event.
     *
     * @param  ArithmeticCreated  $event
     * @return void
     */

    public function handle(ArithmeticCreated $event)
    {
        //
        $this->Arithmetic->store($event->data,$event->opration,$event->task);
    }
}
