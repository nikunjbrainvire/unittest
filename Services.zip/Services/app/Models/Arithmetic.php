<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\QueryException;  
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Factories\Factory;

class Arithmetic extends Model
{
    protected $fillable = ['opration','value_a','value_b','result'];
    
    public function store($data,$opration,$task): Arithmetic
    {
        $storeData = ['opration'=>$opration,'value_a'=>$data['value_a'],'value_b'=>$data['value_b'],'result'=>$task];

        return $this->create($storeData);
    }
}
