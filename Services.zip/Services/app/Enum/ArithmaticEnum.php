<?php

namespace App\Enum;


class ArithmaticEnum
{

    public const ADDITION = '1';
    public const SUBSTRACTION = '2';
    public const MULTICATION = '3';
    public const DIVISION = '4';    
}

?>