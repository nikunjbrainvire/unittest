<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\ArithmeticService;
use validate;
use Session;
use Illuminate\Validation\ValidationException;
use App\Events\ArithmeticCreated;
use App\Models\Arithmetic;
use App\Jobs\SendMailJob;

class ArithmeticController extends Controller
{
    /**
     * Construct
     * @param ArithmeticService $services
     */

    /**
    * @var ArithmeticService instance
    */
    private $services;

    public function __construct(ArithmeticService $services)
    {
        $this->services = $services;
    }

    /**
     * Validation & send to Service Data
     * @param Request $request
     *
     * return of ArithmeticService service
     * @param $operationData
     *
     * @return redirect
     */

    /**
    * @array Request request
    * @var $operationData
    */
    private $request;
    private $operationData;

    public function index(Request $request)
    {
        try {
            $this->validate($request, [
            'value_a' => 'required|integer',
            'value_b' => 'required|integer',
            'operation' => 'required'
            ]);

            $operationData = $this->services->operation($request->input());

            return redirect('calculator/index')->with($operationData[0], $operationData[1]);
        } catch (\Exception $e) {
            return redirect('calculator/index')->with("danger", $e->getMessage());
        }
    }
}
