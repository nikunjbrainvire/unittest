<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Support\Facades\Mail;
use Session;

class SendMailJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

     /**
     * Construct
     * @param string $oprationResult
     */

     /**
     * @var oprationResult instance
     */

    public $oprationResult;

    public function __construct(string $oprationResult)
    {
        $this->oprationResult = $oprationResult;
    }

/**
     * Dispatch an SendMailJob
     * @param message $this->oprationResult
     */

   public function handle()
    {
        Mail::send([], [], function($message) {
            $message->to('abc@gmail.com', 'Tutorials Point')
            ->subject('Your Result')
            ->setBody($this->oprationResult);
            $message->from('xyz@gmail.com','Virat Gandhi');
        });   
    }
}

