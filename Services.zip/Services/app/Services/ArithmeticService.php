<?php

namespace App\Services;

use Illuminate\Http\Request;
use App\Models\Arithmetic;
use App\Enum\ArithmaticEnum;
use App\Jobs\SendMailJob;
use Session;
use Illuminate\Validation\ValidationException;
use Exception;
use App\Events\ArithmeticCreated;

class ArithmeticService
{

    /**
     * Perform an Operation
     * @param array $data
     *
     * Dispatch an Event order
     * @param event ArithmeticCreated
     *
     * Dispatch an queue
     * @param Dispatch SendMailJob
     *
     * @return oprationResult
     *
     * @throws Exception
     */

    /**
     * @var opration instance
     * @int task instance
     * @var oprationResult instance
     */
    private $opration;
    private $task;
    private $oprationResult;

    public function operation(array $data): array
    {

        switch ($data['operation']) {
            case ArithmaticEnum::ADDITION:
                $opration = "Addition";
                $task = ( (int)$data['value_a'] + (int)$data['value_b'] );
                break;
            case ArithmaticEnum::SUBSTRACTION:
                $opration = "Substraction";
                $task = ( (int)$data['value_a'] - (int)$data['value_b'] );
                break;
            case ArithmaticEnum::MULTICATION:
                $opration = "Multiplication";
                $task = ( (int)$data['value_a'] * (int)$data['value_b'] );
                break;
            case ArithmaticEnum::DIVISION:
                $opration = "Division";
                $task = ( (int)$data['value_a'] / (int)$data['value_b'] );
                break;
            default:
                throw new \Exception('Some thing is Wrong Please Try Again');
        }

            $oprationResult = array("success");
            array_push($oprationResult, $opration . " = " . $task);

            $event = ArithmeticCreated::dispatch($data, $opration, $task);

        if ($event) {
            SendMailJob::dispatch($oprationResult[1])->delay(now()->addSeconds(5));
            return $oprationResult;
        } else {
            throw new \Exception("Database Issue");
        }
    }
}
